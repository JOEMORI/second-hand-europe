// 檢查收藏的商品是否已經賣掉或下架。下架的自動移出收藏（可以在「最近自動移除」復原）；
// 頁面寫著已售出的留在收藏、標成「已售出」（成交價可以當行情參考），要清掉按「清除已售出」。
// 還在的商品順便讀頁面上的價格，降價的記下原價（卡片上顯示、背景跳通知）。
// 背景定時檢查（約 12 小時一次）和收藏頁的「立即檢查」都用這裡的程式。
//
// 判斷方式，保守為主，讀不到就當作還在：
//   - 網站回 404 / 410（找不到、已刪除）：確定下架，直接移除
//   - 被轉到別的頁面（例如分類頁）、頁面寫著已售出 / 已結束：可能下架，
//     連續兩次檢查都這樣才移除，避免網站一時出錯就誤刪
//   - 頁面明確寫著已售出（Vinted 的商品資料、eBay 的「已售出」說明）：標成已售出，不移除、不再檢查
//   - 被擋、要驗證、網路錯誤：不判斷，下次再查

import { fmt } from './sources.js';

const SOFT_RECHECK = 2 * 3600e3;        // 第一次「可能下架」後 2 小時再確認一次
const RECHECK_EVERY = 10 * 3600e3;      // 每件商品約 10 小時查一次
const KEEP_REMOVED = 30 * 86400e3;      // 「最近自動移除」保留 30 天

// 從商品網址取出商品編號，用來判斷轉址後是不是同一件商品
export function listingKey(url) {
  try {
    const u = new URL(url);
    const p = u.pathname;
    const m = p.match(/\/items\/(\d+)/) || p.match(/\/itm\/(?:[^/]+\/)?(\d+)/) || p.match(/\/(m\d{6,})/)
      || p.match(/-(ID\w+)\.html/) || p.match(/(\d{6,})/) || u.search.match(/(?:adId|id)=(\d+)/i);
    return m ? m[1] : null;
  } catch { return null; }
}

// 頁面上明確寫著已售出（各網站的寫法）
const SOLD = [
  /schema\.org\/SoldOut"/,                                                  // 很多網站的結構化資料
  /This listing sold on|Dieser Artikel wurde (am [^<]{1,40}? )?verkauft|Dieses Angebot wurde am [^<]{1,40}? verkauft/i,   // eBay
];

// 頁面上明確寫著已結束、已刪除（各網站的寫法）
const ENDED = [
  /schema\.org\/Discontinued"/,                                             // 很多網站的結構化資料
  /Dieses Angebot wurde (vom Verkäufer )?beendet|Diese Auktion (ist|wurde) beendet|This listing (was ended|has ended)|Der Verkäufer hat diesen Artikel beendet/i,   // eBay
  /Die Anzeige ist nicht mehr verfügbar|Diese Anzeige ist (leider )?nicht mehr verfügbar|Anzeige wurde gelöscht/i,   // Kleinanzeigen、willhaben
  /Inzerát (byl smazán|neexistuje|nebyl nalezen)|Inzerát (bol|bol už) (zmazaný|vymazaný)|Inzerát neexistuje/i,   // Bazoš
  /Questo annuncio non è più disponibile|Annuncio (scaduto|rimosso|non più disponibile)/i,   // Subito
  /Deze advertentie is niet (meer )?beschikbaar|Deze advertentie is verwijderd/i,   // Marktplaats、2dehands
];

// 回傳 'sold'（已售出）、'ended'（已結束 / 刪除）或 null（看起來還在）
export function pageState(url, html) {
  if (/vinted\./.test(url)) {
    const id = listingKey(url);
    if (!id) return null;
    // Vinted 的商品資料（欄位照字母排序，用商品編號對到這一件，不會看到頁面上其他推薦商品）：
    // 賣掉後 is_closed 變成 true，頁面上顯示「Verkocht / Sold」
    const c = html.match(new RegExp('\\\\"is_closed\\\\":(true|false),\\\\"item_id\\\\":\\\\"' + id + '\\\\"'));
    if (c) return c[1] === 'true' ? 'sold' : null;
    // 舊版頁面：專門描述能不能買的一段，can_buy 是 false、又不是保留中就是賣掉了；被隱藏算下架
    const m = html.match(new RegExp('\\{\\\\"can_buy\\\\":(true|false)[^{}]{0,300}?\\\\"item_id\\\\":\\\\"' + id + '\\\\"'));
    if (!m) return null;
    if (/\\"is_hidden\\":true/.test(m[0])) return 'ended';
    return m[1] === 'false' && !/\\"is_reserved\\":true/.test(m[0]) ? 'sold' : null;
  }
  // 結構化資料同時寫著有貨的話，以有貨為準
  if (/schema\.org\/InStock"/.test(html)) return null;
  // 北歐的 DBA、Blocket、Tori 每件都是單一商品，缺貨就是賣掉了
  if (/(dba\.dk|blocket\.se|tori\.fi)\//.test(url) && /schema\.org\/OutOfStock"/.test(html)) return 'sold';
  if (SOLD.some(re => re.test(html))) return 'sold';
  return ENDED.some(re => re.test(html)) ? 'ended' : null;
}

const BLOCKED = /captcha-delivery|geo\.captcha|awswaf|challenge-platform|Human Verification|pardon our interruption|Bitte entschuldigen Sie die Störung|splashui\/(challenge|captcha)|Just a moment/i;

// 價格字串轉數字：360、"1650.00"、"1.650,00"、"1,650.00"
function priceNum(v) {
  if (typeof v === 'number') return v;
  let t = String(v ?? '').trim().replace(/[^\d.,]/g, '');
  if (!t) return null;
  if (/^\d{1,3}(\.\d{3})+(,\d{1,2})?$/.test(t)) t = t.replace(/\./g, '').replace(',', '.');
  else if (/^\d+,\d{1,2}$/.test(t)) t = t.replace(',', '.');
  else t = t.replace(/,/g, '');
  const n = parseFloat(t);
  return Number.isFinite(n) ? n : null;
}

// 從商品頁讀價格：先看結構化資料（schema.org 的 Offer，Marktplaats、2dehands、willhaben、eBay 等），
// 再看 itemprop="price"（Kleinanzeigen），最後看 eBay 商品頁的主要價格區塊。讀不到就回傳 null，不猜。
export function pagePrice(html) {
  for (const m of html.matchAll(/<script[^>]*application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi)) {
    let d;
    try { d = JSON.parse(m[1]); } catch { continue; }
    const stack = [d];
    while (stack.length) {
      const x = stack.pop();
      if (!x || typeof x !== 'object') continue;
      if (Array.isArray(x)) { stack.push(...x); continue; }
      const type = [].concat(x['@type'] || []);
      if (type.includes('Offer') || type.includes('AggregateOffer')) {
        const p = priceNum(x.price ?? x.lowPrice);
        if (p > 0) return { price: p, currency: x.priceCurrency || null };
      }
      if (x.offers) stack.push(x.offers);
      if (x['@graph']) stack.push(x['@graph']);
    }
  }
  const m = html.match(/itemprop="price"\s+content="([\d.,]+)"/) || html.match(/content="([\d.,]+)"\s+itemprop="price"/);
  const p = m && priceNum(m[1]);
  if (p > 0) {
    const c = html.match(/itemprop="priceCurrency"\s+content="([A-Z]{3})"/) || html.match(/content="([A-Z]{3})"\s+itemprop="priceCurrency"/);
    return { price: p, currency: c ? c[1] : null };
  }
  // eBay：<div class="x-price-primary"><span class="ux-textspans">EUR 349,00</span>（拍賣頁另外有出價資訊，不讀）
  const e = html.match(/class="x-price-primary"[^>]*>(?:\s*<[^>]+>\s*){0,3}(EUR|€)\s*([\d.,]+)/);
  const pe = e && priceNum(e[2]);
  if (pe > 0) return { price: pe, currency: 'EUR' };
  return null;
}

// 回傳 { status, price, currency }。status：'gone'（確定下架）、'soft'（可能下架）、'sold'（已售出）、'live'（還在）、'unknown'（讀不到）
export async function listingCheck(url) {
  let res;
  try {
    res = await fetch(url, { credentials: 'include', redirect: 'follow', signal: AbortSignal.timeout(15000) });
  } catch { return { status: 'unknown' }; }
  if (res.status === 404 || res.status === 410) return { status: 'gone' };
  if (!res.ok) return { status: 'unknown' };
  const key = listingKey(url);
  if (res.redirected && key && !res.url.includes(key)) {
    // 被轉到登入、同意或驗證頁，不代表下架
    if (/login|signin|anmelden|inloggen|consent|captcha|challenge|verif/i.test(res.url)) return { status: 'unknown' };
    return { status: 'soft' };
  }
  let html;
  try { html = await res.text(); } catch { return { status: 'unknown' }; }
  if (html.length < 60000 && BLOCKED.test(html)) return { status: 'unknown' };
  const st = pageState(url, html);
  if (st === 'sold') return { status: 'sold' };
  if (st === 'ended') return { status: 'soft' };
  return { status: 'live', ...(pagePrice(html) || {}) };
}
export const listingStatus = async url => (await listingCheck(url)).status;

// 價格有變：更新收藏的價格；降價時記下原價（priceWas），之後再漲回原價以上就拿掉標示。
// 只處理歐元標價、不是拍賣或起標的商品；讀到的價格跟原本差太多（不到 1/5 或超過 5 倍）不相信
export function applyPrice(f, r, t, dropped) {
  const p = r?.price;
  if (!(p > 0) || !(f.price > 0) || f.currency !== 'EUR' || (r.currency && r.currency !== 'EUR')) return f;
  if (f.openPrice || f.isAuction || /起標|bids from/i.test(f.priceLabel || '')) return f;
  if (Math.abs(p - f.price) < 0.5 || p < f.price * 0.2 || p > f.price * 5) return f;
  const out = { ...f, price: p, priceLabel: `€ ${fmt(p)}` };
  if (f.total != null) out.total = Math.round((f.total - f.price + p) * 100) / 100;
  if (p < f.price) {
    out.priceWas = Math.max(f.priceWas || 0, f.price);
    out.priceDropAt = t;
    dropped.push(out);
  } else if (f.priceWas && p >= f.priceWas) {
    delete out.priceWas;
    delete out.priceDropAt;
  }
  return out;
}

// 檢查到期的收藏，把下架的移到 favRemoved。
// force：不管多久前查過、也不管自動移除有沒有開，全部重查（收藏頁的「立即檢查」）
export async function checkFavorites({ limit = 40, force = false, onProgress, gap = 700 } = {}) {
  const now = Date.now();
  const { favorites = [], favAutoRemove = true, favCheckLock = 0 } = await chrome.storage.local.get(['favorites', 'favAutoRemove', 'favCheckLock']);
  if (!favAutoRemove && !force) return { checked: 0, removed: [] };
  // 背景和收藏頁不要同時檢查
  if (now - favCheckLock < 10 * 60e3) return { checked: 0, removed: [], busy: true };
  // 已售出的不再檢查
  const due = favorites
    .filter(f => f.url && !f.soldAt && (force || now - (f.checkedAt || 0) > RECHECK_EVERY))
    .sort((a, b) => (a.checkedAt || 0) - (b.checkedAt || 0))
    .slice(0, limit);
  if (!due.length) {
    await chrome.storage.local.set({ favCheckedAt: now });
    return { checked: 0, removed: [], dropped: [], sold: [] };
  }
  await chrome.storage.local.set({ favCheckLock: now });
  const results = new Map();
  try {
    for (let i = 0; i < due.length; i++) {
      results.set(due[i].id, await listingCheck(due[i].url));
      onProgress?.(i + 1, due.length);
      // 慢慢查，不要一次對網站送一堆請求；寫入儲存區也讓背景程式不會被 Chrome 暫停
      await chrome.storage.local.set({ favCheckLock: Date.now() });
      // Vinted 對連續請求很敏感，間隔拉長到 3 秒，避免你自己的 Vinted 分頁被要求驗證
      const wait = /vinted\./.test(due[i].url) ? Math.max(gap, 3000) : gap;
      if (i < due.length - 1) await new Promise(r => setTimeout(r, wait));
    }
  } finally {
    // 檢查期間你可能新增或移除了收藏：以最新的收藏清單為準
    const { favorites: cur = [], favRemoved = [] } = await chrome.storage.local.get(['favorites', 'favRemoved']);
    const t = Date.now();
    const removed = [], next = [], dropped = [], sold = [];
    for (const f of cur) {
      const r = results.get(f.id), st = r?.status;
      if (!st) { next.push(f); continue; }
      // 已售出：留在收藏，標上售出時間（放回收藏的也一樣）
      if (st === 'sold') {
        const out = { ...f, checkedAt: t, goneHits: 0, soldAt: f.soldAt || t };
        if (!f.soldAt) sold.push(out);
        next.push(out);
        continue;
      }
      // 放回收藏的商品（keep）不自動移除，但價格照樣更新
      if (f.keep) { next.push(st === 'live' ? applyPrice({ ...f, checkedAt: t }, r, t, dropped) : f); continue; }
      if (st === 'unknown') { next.push({ ...f, checkedAt: t }); continue; }
      if (st === 'live') { next.push(applyPrice({ ...f, checkedAt: t, goneHits: 0 }, r, t, dropped)); continue; }
      // 「可能下架」的第二次確認至少要隔 2 小時（連按「立即檢查」不算），避免網站一時出錯就誤刪
      if (st === 'soft' && f.goneHits >= 1 && t - (f.goneAt || 0) < SOFT_RECHECK) { next.push({ ...f, checkedAt: t - RECHECK_EVERY + SOFT_RECHECK }); continue; }
      const hits = st === 'gone' ? 2 : (f.goneHits || 0) + 1;
      if (hits >= 2) removed.push({ ...f, removedAt: t, goneHits: hits });
      else next.push({ ...f, goneHits: hits, goneAt: t, checkedAt: t - RECHECK_EVERY + SOFT_RECHECK });
    }
    const keptRemoved = [...removed, ...favRemoved].filter(x => t - (x.removedAt || 0) < KEEP_REMOVED).slice(0, 100);
    await chrome.storage.local.set({ favorites: next, favRemoved: keptRemoved, favCheckedAt: t, favCheckLock: 0 });
    checkFavorites.last = { checked: results.size, removed, dropped, sold };
  }
  return checkFavorites.last;
}

// 清除已售出：移到「最近自動移除」（30 天內還可以放回收藏）
export async function clearSold() {
  const { favorites = [], favRemoved = [] } = await chrome.storage.local.get(['favorites', 'favRemoved']);
  const t = Date.now();
  const out = favorites.filter(f => f.soldAt).map(f => ({ ...f, removedAt: t }));
  if (!out.length) return 0;
  await chrome.storage.local.set({
    favorites: favorites.filter(f => !f.soldAt),
    favRemoved: [...out, ...favRemoved].filter(x => t - (x.removedAt || 0) < KEEP_REMOVED).slice(0, 100),
  });
  return out.length;
}

// 復原：放回收藏，之後不再自動移除這一件
export async function restoreFavorite(id) {
  const { favorites = [], favRemoved = [] } = await chrome.storage.local.get(['favorites', 'favRemoved']);
  const it = favRemoved.find(x => x.id === id);
  if (!it) return;
  const { removedAt, goneHits, goneAt, ...rest } = it;
  await chrome.storage.local.set({
    favorites: favorites.some(f => f.id === id) ? favorites : [{ ...rest, keep: true }, ...favorites],
    favRemoved: favRemoved.filter(x => x.id !== id),
  });
}
